from main import repo_name_to_student_name
import pandas as pd
import re

df = pd.read_csv("final_data.csv", header=[0, 1], index_col=0)

STUDENTS = list(df.iloc[:, 0].keys())

regexes = {}

normal_chars = "abcdefghijklmnopqrstuvwxyz-"

def accent_to_code(char):
    return format(ord(char), "#06x").replace("0x", "\\u")

def code_to_accent(code):
    return chr(int(code.replace("\\u", "0x"), 16))

def non_letters_into_codes(name):
    lst = [_ for _ in name]
    for i in range(len(lst)):
        char = lst[i]
        if char.lower() not in normal_chars:
            lst[i] = accent_to_code(char)
    return "".join(lst)

#\u00e1

for student in STUDENTS:
    val = ";".join(repo_name_to_student_name(student.split(";")))
    regexes[student] = val
    regexes[non_letters_into_codes(student.split(";")[0]) + ";" + student.split(";")[1]] = val

with open('final_data.json', 'r') as file:
    content = file.read()
    for key in regexes:
        if "\\u" in key: print(key)
        content = re.sub(re.escape(key), regexes[key], content)
    #content = re.sub(re.escape("https://fabacademy.org/2018/labs/crunchlab/students/gianluca-derossi/"), "https://fabacademy.org/2019/labs/crunchlab/students/gianluca-derossi/", content) DIDNT WORK SO DID IT BY HAND
    
with open('final_data_name_fixed.json', 'w', encoding='utf-8') as file: # encoding so special characters in names can be written without UnicodeEncodeError
    file.write(content)